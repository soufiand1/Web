import { Instagram, Phone } from 'lucide-react';
import { FaWhatsapp } from 'react-icons/fa';
import { useLanguage } from '../context/LanguageContext';

export default function Footer() {
  const { language, t } = useLanguage();
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-dark-primary border-t border-gray-800 pt-12 pb-6">
      <div className="container mx-auto px-4 md:px-6">
        <div className={`grid grid-cols-1 md:grid-cols-3 gap-8 mb-12 ${language === 'ar' ? 'text-right' : 'text-left'}`}>
          {/* Company Info */}
          <div className="md:col-span-1">
            <h3 className="text-xl font-bold text-white mb-4">
              <span className="text-neon-primary">Sd</span>creators
            </h3>
            <p className={`text-gray-300 mb-6 max-w-md leading-relaxed ${language === 'ar' ? 'md:mr-0 md:ml-auto' : 'md:ml-0 md:mr-auto'}`}>
              {t('footer.description')}
            </p>
            <div className={`flex space-x-4 ${language === 'ar' ? 'justify-end md:justify-start space-x-reverse' : 'justify-start'}`}>
              <a 
                href="https://instagram.com/sd.creators" 
                className="w-10 h-10 rounded-full bg-dark-secondary flex items-center justify-center text-neon-primary hover:bg-neon-primary hover:text-dark-primary transition-all shadow-neon"
                aria-label="Instagram"
              >
                <Instagram size={20} />
              </a>
              <a 
                href="https://wa.me/212631808007" 
                className="w-10 h-10 rounded-full bg-dark-secondary flex items-center justify-center text-neon-primary hover:bg-neon-primary hover:text-dark-primary transition-all shadow-neon"
                aria-label="WhatsApp"
              >
                <FaWhatsapp size={20} />
              </a>
            </div>
          </div>
          
          {/* Quick Links */}
          <div className={language === 'ar' ? 'text-right' : 'text-left'}>
            <h4 className="text-white font-semibold mb-4">{t('footer.quickLinks')}</h4>
            <ul className="space-y-2">
              <li>
                <a href="#services" className="text-gray-300 hover:text-neon-primary transition-colors">{t('footer.services')}</a>
              </li>
              <li>
                <a href="#transformations" className="text-gray-300 hover:text-neon-primary transition-colors">{t('footer.transformations')}</a>
              </li>
              <li>
                <a href="#benefits" className="text-gray-300 hover:text-neon-primary transition-colors">{t('footer.benefits')}</a>
              </li>
              <li>
                <a href="#portfolio" className="text-gray-300 hover:text-neon-primary transition-colors">{t('footer.ourWork')}</a>
              </li>
              <li>
                <a href="#pricing" className="text-gray-300 hover:text-neon-primary transition-colors">{t('footer.pricing')}</a>
              </li>
              <li>
                <a href="#faq" className="text-gray-300 hover:text-neon-primary transition-colors">{t('footer.faq')}</a>
              </li>
              <li>
                <a href="#contact" className="text-gray-300 hover:text-neon-primary transition-colors">{t('footer.contact')}</a>
              </li>
            </ul>
          </div>
          
          {/* Contact */}
          <div className={language === 'ar' ? 'text-right' : 'text-left'}>
            <h4 className="text-white font-semibold mb-4">{t('footer.contactUs')}</h4>
            <ul className="space-y-3">
              <li className={`flex items-center text-gray-300 ${language === 'ar' ? 'flex-row-reverse justify-end' : ''}`}>
                <Phone size={16} className={`text-neon-primary ${language === 'ar' ? 'ml-2' : 'mr-2'}`} />
                <a href="tel:+212631808007" className="hover:text-neon-primary transition-colors">
                  +212 631 808 007
                </a>
              </li>
              <li className={`flex items-center text-gray-300 ${language === 'ar' ? 'flex-row-reverse justify-end' : ''}`}>
                <FaWhatsapp size={16} className={`text-neon-primary ${language === 'ar' ? 'ml-2' : 'mr-2'}`} />
                <a href="https://wa.me/212631808007" className="hover:text-neon-primary transition-colors">
                  WhatsApp
                </a>
              </li>
              <li className={`flex items-center text-gray-300 ${language === 'ar' ? 'flex-row-reverse justify-end' : ''}`}>
                <Instagram size={16} className={`text-neon-primary ${language === 'ar' ? 'ml-2' : 'mr-2'}`} />
                <a href="https://instagram.com/sd.creators" className="hover:text-neon-primary transition-colors">
                  @sd.creators
                </a>
              </li>
            </ul>
          </div>
        </div>
        
        {/* Copyright */}
        <div className="pt-6 border-t border-gray-800 text-center text-gray-400 text-sm">
          <p>&copy; {currentYear} Sdcreators. {t('footer.rights')}</p>
        </div>
      </div>
    </footer>
  );
}
