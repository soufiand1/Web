import { useEffect, useState } from 'react';
import { motion, useAnimation } from 'framer-motion';
import { useLanguage } from '../context/LanguageContext';

const floatingElements = [
  { text: 'Bardage', color: '#00f2ff', arabic: 'كسوة خشب' },
  { text: 'Wall Finishes', color: '#fb00ff', arabic: 'تشطيبات الجدران' },
  { text: 'Papier Peint', color: '#00f2ff', arabic: 'ورق الحائط' },
  { text: 'Lighting', color: '#fb00ff', arabic: 'إضاءة' },
  { text: 'Parquet', color: '#00f2ff', arabic: 'باركيه' },
  { text: 'Placo Plâtre', color: '#fb00ff', arabic: 'جبس بورد' },
  { text: 'Shop Design', color: '#00f2ff', arabic: 'تصميم المتاجر' },
  { text: 'Display Areas', color: '#fb00ff', arabic: 'مناطق العرض' },
  { text: 'Store Front', color: '#00f2ff', arabic: 'واجهة المتجر' },
  { text: 'Premium Finish', color: '#fb00ff', arabic: 'تشطيب فاخر' },
  { text: 'Custom Design', color: '#00f2ff', arabic: 'تصميم مخصص' },
  { text: 'Quality Materials', color: '#fb00ff', arabic: 'مواد عالية الجودة' },
];

export default function FloatingElements() {
  const { language } = useLanguage();
  const [windowSize, setWindowSize] = useState({
    width: typeof window !== 'undefined' ? window.innerWidth : 0,
    height: typeof window !== 'undefined' ? window.innerHeight : 0,
  });

  useEffect(() => {
    const handleResize = () => {
      setWindowSize({
        width: window.innerWidth,
        height: window.innerHeight,
      });
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
      {floatingElements.map((element, index) => (
        <FloatingElement
          key={index}
          text={language === 'ar' ? element.arabic : element.text}
          color={element.color}
          index={index}
          windowSize={windowSize}
        />
      ))}
    </div>
  );
}

interface FloatingElementProps {
  text: string;
  color: string;
  index: number;
  windowSize: { width: number; height: number };
}

function FloatingElement({ text, color, index, windowSize }: FloatingElementProps) {
  const controls = useAnimation();
  
  // Generate random positions based on window size
  const getRandomPosition = () => {
    return {
      x: Math.random() * windowSize.width * 0.8,
      y: Math.random() * windowSize.height * 0.8,
    };
  };
  
  // Initial random position
  const [position] = useState(getRandomPosition());

  useEffect(() => {
    // Animate in a random path
    const animate = async () => {
      while (true) {
        const newPosition = getRandomPosition();
        await controls.start({
          x: newPosition.x,
          y: newPosition.y,
          transition: {
            duration: 30 + Math.random() * 40,
            ease: "linear"
          }
        });
      }
    };
    
    animate();
  }, [controls, windowSize]);

  return (
    <motion.div
      className="absolute text-sm md:text-base font-medium rounded-full px-3 py-1 opacity-20 mix-blend-screen"
      style={{ 
        backgroundColor: color,
        color: '#000',
        textShadow: `0 0 5px ${color}`,
        boxShadow: `0 0 10px ${color}`,
        left: position.x,
        top: position.y,
      }}
      animate={controls}
      initial={{ opacity: 0 }}
      whileInView={{ opacity: 0.2 }}
      viewport={{ once: false }}
    >
      {text}
    </motion.div>
  );
}
