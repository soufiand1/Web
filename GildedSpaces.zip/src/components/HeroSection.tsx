import { motion, useScroll, useTransform } from 'framer-motion';
import { useLanguage } from '../context/LanguageContext';
import { useRef, useEffect, useState } from 'react';

export default function HeroSection() {
  const { language, t } = useLanguage();
  const sectionRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ["start start", "end start"]
  });
  
  // Parallax effect values
  const y = useTransform(scrollYProgress, [0, 1], ['0%', '40%']);
  const opacity = useTransform(scrollYProgress, [0, 0.8], [1, 0]);
  const scale = useTransform(scrollYProgress, [0, 1], [1, 1.1]);
  
  // Interactive elements state
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  
  // Handle mouse movement for interactive elements
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      const { clientX, clientY } = e;
      const centerX = window.innerWidth / 2;
      const centerY = window.innerHeight / 2;
      
      setMousePosition({
        x: (clientX - centerX) / centerX,
        y: (clientY - centerY) / centerY
      });
    };
    
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);
  
  return (
    <div ref={sectionRef} className="relative min-h-screen w-full overflow-hidden">
      {/* Enhanced Parallax Background */}
      <motion.div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ 
          backgroundImage: 'url("https://images.unsplash.com/photo-1604014237800-1c9102c219da?q=80&w=1770&auto=format&fit=crop")', 
          filter: 'brightness(0.4)',
          y,
          scale,
        }}
      />
      
      {/* Advanced Gradient Overlay */}
      <motion.div 
        className="absolute inset-0 bg-gradient-radial from-transparent via-dark-primary/80 to-dark-primary"
        style={{ opacity }}
      />
      
      {/* Dynamic Color Overlay */}
      <motion.div 
        className="absolute inset-0 bg-gradient-to-b from-neon-primary/5 to-dark-primary mix-blend-overlay"
        style={{ 
          opacity: useTransform(scrollYProgress, [0, 0.5], [0.7, 0]),
        }}
      />
      
      {/* Enhanced 3D Neon Grid Effect */}
      <motion.div 
        className="absolute inset-0 opacity-10" 
        style={{ 
          backgroundImage: 'linear-gradient(to right, #00f2ff 1px, transparent 1px), linear-gradient(to bottom, #00f2ff 1px, transparent 1px)',
          backgroundSize: '40px 40px',
          transformStyle: 'preserve-3d',
          transform: `rotateX(${mousePosition.y * 5}deg) rotateY(${mousePosition.x * 5}deg)`,
        }}
        animate={{
          backgroundPosition: ['0px 0px', '40px 40px'],
        }}
        transition={{
          duration: 20,
          repeat: Infinity,
          ease: "linear"
        }}
      />
      
      {/* Distant Particles Layer */}
      <div className="absolute inset-0 overflow-hidden opacity-40 pointer-events-none">
        {[...Array(30)].map((_, i) => (
          <motion.div
            key={`distant-${i}`}
            className="absolute w-1 h-1 rounded-full bg-white"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              filter: 'blur(1px)',
            }}
            animate={{
              scale: [1, 1.5, 1],
              opacity: [0.3, 0.8, 0.3],
            }}
            transition={{
              duration: 3 + Math.random() * 5,
              repeat: Infinity,
              delay: Math.random() * 5,
              ease: "easeInOut"
            }}
          />
        ))}
      </div>

      {/* Advanced Floating Neon Particles with Mouse Interaction */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(40)].map((_, i) => {
          const size = Math.random() * 2 + 1;
          const initialX = Math.random() * 100;
          const initialY = Math.random() * 100;
          
          return (
            <motion.div
              key={i}
              className={`absolute rounded-full ${i % 2 === 0 ? 'bg-neon-primary' : 'bg-neon-accent'} shadow-neon`}
              style={{
                left: `${initialX}%`,
                top: `${initialY}%`,
                width: `${size}px`,
                height: `${size}px`,
                boxShadow: `0 0 ${size * 3}px ${i % 2 === 0 ? '#00f2ff' : '#fb00ff'}`,
                zIndex: Math.floor(size),
                x: mousePosition.x * (i % 10) * -1,
                y: mousePosition.y * (i % 15) * -1,
              }}
              animate={{
                y: [0, Math.random() * -150 - 50],
                x: [0, (Math.random() - 0.5) * 100],
                opacity: [0, 0.8, 0],
                scale: [1, 1.2, 0.8, 1],
              }}
              transition={{
                duration: 5 + Math.random() * 10,
                repeat: Infinity,
                delay: Math.random() * 5,
                ease: "easeInOut"
              }}
            />
          );
        })}
      </div>
      
      {/* Horizontal light streaks */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(10)].map((_, i) => (
          <motion.div
            key={`streak-${i}`}
            className="absolute h-px bg-gradient-to-r from-transparent via-neon-primary to-transparent"
            style={{
              width: `${30 + Math.random() * 40}%`,
              top: `${Math.random() * 100}%`,
              left: `-20%`,
              opacity: 0.3,
            }}
            animate={{
              left: ['120%', '-20%'],
            }}
            transition={{
              duration: 10 + Math.random() * 20,
              repeat: Infinity,
              delay: Math.random() * 10,
              ease: "linear"
            }}
          />
        ))}
      </div>
      
      {/* Content */}
      <div className={`relative h-full container mx-auto px-4 md:px-6 flex flex-col justify-center items-center text-center z-10 pt-16 ${language === 'ar' ? 'font-arabic' : ''}`}>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="max-w-3xl mx-auto"
        >
          <motion.div
            className="relative inline-block mb-6"
            animate={{ 
              filter: ['drop-shadow(0 0 5px rgba(0,242,255,0.3))', 'drop-shadow(0 0 15px rgba(0,242,255,0.5))', 'drop-shadow(0 0 5px rgba(0,242,255,0.3))'] 
            }}
            transition={{ duration: 3, repeat: Infinity }}
          >
            <motion.h1 
              className="text-4xl md:text-5xl lg:text-7xl font-bold text-white leading-tight"
              dir={language === 'ar' ? 'rtl' : 'ltr'}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1, delay: 0.3 }}
            >
              {language === 'en' ? (
                <>Elevate Your Shop With 
                <div className="relative inline-block">
                  <motion.span 
                    className="relative z-10 text-neon-primary font-extrabold"
                    animate={{ 
                      color: ['#00f2ff', '#ffffff', '#00f2ff'],
                      textShadow: ['0 0 5px rgba(0,242,255,0.5)', '0 0 20px rgba(0,242,255,0.8)', '0 0 5px rgba(0,242,255,0.5)'] 
                    }}
                    transition={{ duration: 5, repeat: Infinity }}
                  > Expert Finishes</motion.span>
                  
                  {/* Decorative glow effect */}
                  <motion.div
                    className="absolute -bottom-3 left-0 right-0 h-1 bg-neon-primary rounded-full blur-sm"
                    animate={{ 
                      opacity: [0.3, 0.8, 0.3],
                      width: ['80%', '110%', '80%'],
                      left: ['10%', '-5%', '10%'],
                    }}
                    transition={{ duration: 5, repeat: Infinity }}
                  />
                </div>
                </>
              ) : (
                <>ارتقِ بمتجرك مع 
                <div className="relative inline-block mr-2">
                  <motion.span 
                    className="relative z-10 text-neon-primary font-extrabold"
                    animate={{ 
                      color: ['#00f2ff', '#ffffff', '#00f2ff'],
                      textShadow: ['0 0 5px rgba(0,242,255,0.5)', '0 0 20px rgba(0,242,255,0.8)', '0 0 5px rgba(0,242,255,0.5)'] 
                    }}
                    transition={{ duration: 5, repeat: Infinity }}
                  >تشطيبات احترافية</motion.span>
                  
                  {/* Decorative glow effect */}
                  <motion.div
                    className="absolute -bottom-3 right-0 left-0 h-1 bg-neon-primary rounded-full blur-sm"
                    animate={{ 
                      opacity: [0.3, 0.8, 0.3],
                      width: ['80%', '110%', '80%'],
                      right: ['10%', '-5%', '10%'],
                    }}
                    transition={{ duration: 5, repeat: Infinity }}
                  />
                </div>
                </>
              )}
            </motion.h1>
          </motion.div>
          
          <motion.p 
            className="text-lg md:text-xl text-gray-300 mb-10 max-w-2xl mx-auto leading-relaxed relative"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.7, delay: 0.7 }}
            dir={language === 'ar' ? 'rtl' : 'ltr'}
          >
            {t('hero.subtitle')}
            
            {/* Decorative accent */}
            <motion.span 
              className="absolute -left-8 top-0 text-4xl text-neon-primary opacity-30"
              animate={{ 
                y: [0, 10, 0],
                opacity: [0.2, 0.4, 0.2],
                rotate: [0, 5, 0]
              }}
              transition={{ duration: 6, repeat: Infinity }}
              style={{ display: language === 'ar' ? 'none' : 'block' }}
            >
              ✧
            </motion.span>
            <motion.span 
              className="absolute -right-8 bottom-0 text-4xl text-neon-accent opacity-30"
              animate={{ 
                y: [0, -10, 0],
                opacity: [0.2, 0.4, 0.2],
                rotate: [0, -5, 0]
              }}
              transition={{ duration: 5, repeat: Infinity }}
              style={{ display: language === 'ar' ? 'none' : 'block' }}
            >
              ✦
            </motion.span>
            
            {/* Arabic decorative accents */}
            <motion.span 
              className="absolute -right-8 top-0 text-4xl text-neon-primary opacity-30"
              animate={{ 
                y: [0, 10, 0],
                opacity: [0.2, 0.4, 0.2],
                rotate: [0, -5, 0]
              }}
              transition={{ duration: 6, repeat: Infinity }}
              style={{ display: language === 'ar' ? 'block' : 'none' }}
            >
              ✧
            </motion.span>
            <motion.span 
              className="absolute -left-8 bottom-0 text-4xl text-neon-accent opacity-30"
              animate={{ 
                y: [0, -10, 0],
                opacity: [0.2, 0.4, 0.2],
                rotate: [0, 5, 0]
              }}
              transition={{ duration: 5, repeat: Infinity }}
              style={{ display: language === 'ar' ? 'block' : 'none' }}
            >
              ✦
            </motion.span>
          </motion.p>
          
          <motion.div 
            className="flex flex-col sm:flex-row items-center justify-center gap-4"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.7 }}
          >
            <motion.a 
              href="#services" 
              className="px-8 py-4 bg-neon-primary hover:bg-neon-primary/80 text-gray-900 font-medium rounded-md shadow-neon transition-all w-full sm:w-auto text-center"
              whileHover={{ scale: 1.05, boxShadow: '0 0 20px rgba(0,242,255,0.6)' }}
              whileTap={{ scale: 0.95 }}
            >
              {t('hero.services')}
            </motion.a>
            <motion.a 
              href="tel:+212631808007" 
              className="px-8 py-4 border border-neon-primary bg-dark-primary/50 text-neon-primary hover:bg-neon-primary hover:text-gray-900 font-medium rounded-md shadow-neon transition-all w-full sm:w-auto flex items-center justify-center"
              whileHover={{ scale: 1.05, boxShadow: '0 0 20px rgba(0,242,255,0.6)' }}
              whileTap={{ scale: 0.95 }}
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={language === 'ar' ? 'ml-2' : 'mr-2'}>
                <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
              </svg>
              {t('hero.callNow')}
            </motion.a>
          </motion.div>

          {/* WhatsApp Button */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.9 }}
            className="mt-6"
          >
            <motion.a 
              href="https://wa.me/212631808007" 
              className="inline-flex items-center px-6 py-3 bg-[#25D366] hover:bg-[#1ebea5] text-white font-medium rounded-md transition-all"
              whileHover={{ scale: 1.05, boxShadow: '0 0 15px rgba(37,211,102,0.6)' }}
              whileTap={{ scale: 0.95 }}
            >
              <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 24 24" className={`w-5 h-5 ${language === 'ar' ? 'ml-2' : 'mr-2'}`}>
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
              </svg>
              {language === 'ar' ? "تواصل عبر واتساب" : "Contact via WhatsApp"}
            </motion.a>
          </motion.div>
        </motion.div>
        
        {/* Enhanced Scroll Indicator */}
        <motion.div 
          className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
          animate={{ 
            y: [0, 10, 0],
            opacity: [0.5, 1, 0.5]
          }}
          transition={{ repeat: Infinity, duration: 1.5 }}
        >
          <div className="flex flex-col items-center">
            <span className="text-neon-primary text-sm mb-2">{t('hero.scrollDown')}</span>
            <motion.div 
              className="w-[1px] h-12 bg-neon-primary"
              animate={{ 
                height: ['30px', '50px', '30px'],
                boxShadow: [
                  '0 0 5px rgba(0,242,255,0.3)', 
                  '0 0 15px rgba(0,242,255,0.5)', 
                  '0 0 5px rgba(0,242,255,0.3)'
                ]
              }}
              transition={{ repeat: Infinity, duration: 1.5 }}
            />
          </div>
        </motion.div>
      </div>
    </div>
  );
}
