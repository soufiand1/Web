import { useState, useEffect } from 'react';
import { motion, useScroll, useSpring } from 'framer-motion';

export default function ScrollProgressIndicator() {
  const [isScrolled, setIsScrolled] = useState(false);
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, { 
    stiffness: 100, 
    damping: 30, 
    restDelta: 0.001 
  });

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <>
      {/* Main progress bar */}
      <motion.div 
        className="fixed top-0 left-0 right-0 h-1 bg-neon-primary z-50 origin-left"
        style={{ scaleX }}
      />
      
      {/* Section indicators - right side */}
      <div className={`fixed right-4 top-1/2 transform -translate-y-1/2 z-40 transition-opacity duration-500 ${isScrolled ? 'opacity-100' : 'opacity-0'}`}>
        <div className="flex flex-col gap-4">
          {['hero', 'services', 'transformations', 'benefits', 'portfolio', 'testimonials', 'pricing', 'faq', 'contact'].map((section, index) => (
            <a 
              key={index} 
              href={`#${section}`} 
              className="group relative flex items-center"
            >
              <div className="w-2 h-2 rounded-full bg-gray-500 group-hover:bg-neon-primary transition-all duration-300"></div>
              <div className="absolute right-4 opacity-0 group-hover:opacity-100 whitespace-nowrap bg-dark-primary/90 text-neon-primary px-2 py-1 rounded text-sm transition-all duration-300 translate-x-2 group-hover:translate-x-0">
                {section.charAt(0).toUpperCase() + section.slice(1)}
              </div>
            </a>
          ))}
        </div>
      </div>
      
      {/* Scroll to top button */}
      {isScrolled && (
        <motion.button
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          className="fixed bottom-6 right-6 w-10 h-10 rounded-full bg-neon-primary/20 border border-neon-primary/50 text-neon-primary flex items-center justify-center z-40 hover:bg-neon-primary hover:text-dark-primary transition-all duration-300"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 20 }}
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M14.707 12.707a1 1 0 01-1.414 0L10 9.414l-3.293 3.293a1 1 0 01-1.414-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 010 1.414z" clipRule="evenodd" />
          </svg>
        </motion.button>
      )}
    </>
  );
}
