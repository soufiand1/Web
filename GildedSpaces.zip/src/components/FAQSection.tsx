import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, ChevronUp } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

// FAQ data with both English and Arabic content
const faqData = [
  {
    question: "How long does a typical shop renovation take?",
    answer: "The duration depends on the scope of work, but most shop renovations take 2-4 weeks. Basic refreshes can be completed in as little as 1 week, while complete transformations may take up to 6 weeks.",
    arabic: {
      question: "كم من الوقت يستغرق تجديد المتجر النموذجي؟",
      answer: "تعتمد المدة على نطاق العمل، ولكن معظم عمليات تجديد المتاجر تستغرق من 2 إلى 4 أسابيع. يمكن إكمال التجديدات الأساسية في أسبوع واحد فقط، بينما قد تستغرق التحولات الكاملة ما يصل إلى 6 أسابيع."
    }
  },
  {
    question: "Can I keep my shop open during renovations?",
    answer: "In many cases, yes. We can work in sections or during off-hours to minimize disruption to your business. For more extensive renovations, a temporary closure may be necessary, but we'll work with you to find the best solution.",
    arabic: {
      question: "هل يمكنني إبقاء متجري مفتوحًا أثناء التجديدات؟",
      answer: "في كثير من الحالات، نعم. يمكننا العمل في أقسام أو خلال ساعات خارج أوقات العمل لتقليل الاضطراب في عملك. بالنسبة للتجديدات الأكثر شمولاً، قد يكون الإغلاق المؤقت ضروريًا، لكننا سنعمل معك لإيجاد أفضل حل."
    }
  },
  {
    question: "Do you provide materials or should I purchase them?",
    answer: "We provide all necessary materials for your renovation. We source high-quality products specifically suited for commercial environments, ensuring durability and compliance with safety standards.",
    arabic: {
      question: "هل توفرون المواد أم يجب علي شراؤها؟",
      answer: "نحن نوفر جميع المواد اللازمة للتجديد. نحصل على منتجات عالية الجودة مناسبة خصيصًا للبيئات التجارية، مما يضمن المتانة والامتثال لمعايير السلامة."
    }
  },
  {
    question: "What areas of Morocco do you service?",
    answer: "We primarily serve Casablanca, Rabat, Marrakech, and Tangier. However, we can accommodate projects in other cities for larger renovations. Contact us to discuss your specific location.",
    arabic: {
      question: "ما هي مناطق المغرب التي تقدمون خدماتكم فيها؟",
      answer: "نحن نخدم بشكل أساسي الدار البيضاء والرباط ومراكش وطنجة. ومع ذلك، يمكننا استيعاب المشاريع في مدن أخرى للتجديدات الأكبر. اتصل بنا لمناقشة موقعك المحدد."
    }
  },
  {
    question: "Do you offer maintenance services after completion?",
    answer: "Yes, we offer maintenance packages to keep your renovation looking fresh. This includes touch-ups, cleaning services, and minor repairs as needed. We recommend scheduling regular maintenance every 6-12 months.",
    arabic: {
      question: "هل تقدمون خدمات الصيانة بعد الانتهاء؟",
      answer: "نعم، نقدم باقات صيانة للحفاظ على مظهر التجديد الخاص بك. وهذا يشمل التحسينات وخدمات التنظيف والإصلاحات الصغيرة حسب الحاجة. نوصي بجدولة الصيانة المنتظمة كل 6-12 شهرًا."
    }
  },
  {
    question: "Can you help with permit requirements for commercial renovations?",
    answer: "Yes, we can guide you through the necessary permits required for your commercial renovation. While you'll need to obtain the permits, we'll provide the technical documentation and specifications needed for the application process.",
    arabic: {
      question: "هل يمكنكم المساعدة في متطلبات التصاريح للتجديدات التجارية؟",
      answer: "نعم، يمكننا إرشادك خلال التصاريح اللازمة للتجديد التجاري الخاص بك. بينما ستحتاج إلى الحصول على التصاريح، سنقدم الوثائق الفنية والمواصفات اللازمة لعملية التقديم."
    }
  }
];

export default function FAQSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);
  const { language } = useLanguage();
  const isArabic = language === 'ar';

  const toggleFAQ = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section id="faq" className="py-20 bg-dark-primary relative overflow-hidden">
      {/* Decorative Elements */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-40 left-10 w-80 h-80 bg-neon-primary/5 rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 right-20 w-72 h-72 bg-neon-accent/5 rounded-full blur-3xl"></div>
        <div className="absolute inset-0 opacity-5" 
             style={{ 
               backgroundImage: 'linear-gradient(to right, #00f2ff 1px, transparent 1px), linear-gradient(to bottom, #00f2ff 1px, transparent 1px)',
               backgroundSize: '40px 40px' 
             }}>
        </div>
      </div>
      
      <div className="container mx-auto px-4 md:px-6 relative z-10">
        {/* Section Header */}
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          dir={isArabic ? 'rtl' : 'ltr'}
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-white">
            {isArabic ? (
              <>الأسئلة <span className="text-neon-primary">الشائعة</span></>
            ) : (
              <>Frequently <span className="text-neon-primary">Asked Questions</span></>
            )}
          </h2>
          <div className="w-24 h-1 bg-neon-primary animate-neon-pulse mx-auto mb-6"></div>
          <p className="text-gray-300 max-w-2xl mx-auto">
            {isArabic ? 
              "إجابات على الأسئلة الشائعة حول خدمات تجديد المتاجر التجارية" : 
              "Answers to common questions about our commercial shop renovation services"}
          </p>
        </motion.div>

        {/* FAQ Accordion */}
        <div className="max-w-3xl mx-auto">
          {faqData.map((faq, index) => {
            const currentFaq = isArabic ? { ...faq, ...faq.arabic } : faq;
            const isOpen = openIndex === index;
            
            return (
              <motion.div 
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className={`mb-4 glass rounded-lg overflow-hidden transition-all duration-300 ${
                  isOpen ? 'border border-neon-primary shadow-neon' : 'border border-gray-700'
                }`}
                dir={isArabic ? 'rtl' : 'ltr'}
                whileHover={{ 
                  boxShadow: isOpen ? 
                    '0 0 15px rgba(0, 242, 255, 0.4)' : 
                    '0 0 10px rgba(0, 242, 255, 0.2)'
                }}
              >
                <motion.button
                  className="w-full px-6 py-4 text-left flex items-center justify-between focus:outline-none"
                  onClick={() => toggleFAQ(index)}
                  aria-expanded={isOpen}
                  whileTap={{ scale: 0.99 }}
                >
                  <h3 className="text-lg font-medium text-white">{currentFaq.question}</h3>
                  <motion.div 
                    className="flex-shrink-0 ml-4"
                    animate={{ rotate: isOpen ? 180 : 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    {isOpen ? (
                      <ChevronUp className="text-neon-primary w-5 h-5" />
                    ) : (
                      <ChevronDown className="text-neon-primary w-5 h-5" />
                    )}
                  </motion.div>
                </motion.button>
                
                <AnimatePresence>
                  {isOpen && (
                    <motion.div 
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.3 }}
                      className="overflow-hidden"
                    >
                      <div className="px-6 pb-4 text-gray-300 leading-relaxed">
                        {currentFaq.answer}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            );
          })}
        </div>
        
        {/* Additional Question */}
        <motion.div 
          className="text-center mt-12"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.3 }}
        >
          <div className="glass p-8 rounded-xl max-w-2xl mx-auto border border-neon-primary/30">
            <p className="text-gray-300 mb-6 text-lg" dir={isArabic ? 'rtl' : 'ltr'}>
              {isArabic ? 
                "هل لديك سؤال آخر لم تتم الإجابة عليه هنا؟ تواصل معنا مباشرة!" : 
                "Have another question that's not answered here? Contact us directly!"}
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <motion.a 
                href="https://wa.me/212631808007" 
                className="inline-flex items-center px-6 py-3 bg-neon-primary hover:bg-neon-primary/80 text-gray-900 font-medium rounded-md shadow-neon transition-all w-full sm:w-auto justify-center"
                whileHover={{ scale: 1.05, boxShadow: '0 0 15px rgba(0, 242, 255, 0.5)' }}
                whileTap={{ scale: 0.95 }}
              >
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 24 24" className={`w-5 h-5 ${isArabic ? 'ml-2' : 'mr-2'}`}>
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                </svg>
                {isArabic ? "اسألنا على واتساب" : "Ask us on WhatsApp"}
              </motion.a>
              
              <motion.a 
                href="tel:+212631808007" 
                className="inline-flex items-center px-6 py-3 bg-dark-primary border border-neon-primary text-neon-primary hover:bg-neon-primary hover:text-gray-900 font-medium rounded-md shadow-neon transition-all w-full sm:w-auto justify-center"
                whileHover={{ scale: 1.05, boxShadow: '0 0 15px rgba(0, 242, 255, 0.5)' }}
                whileTap={{ scale: 0.95 }}
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={`${isArabic ? 'ml-2' : 'mr-2'}`}>
                  <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
                </svg>
                {isArabic ? "اتصل بنا" : "Call Us"}
              </motion.a>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
