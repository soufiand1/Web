import { motion } from 'framer-motion';
import { Instagram, Phone } from 'lucide-react';
import { FaWhatsapp } from 'react-icons/fa';
import { useLanguage } from '../context/LanguageContext';

export default function ContactSection() {
  const { language, t } = useLanguage();

  return (
    <section id="contact" className="py-20 bg-dark-secondary">
      <div className="container mx-auto px-4 md:px-6">
        {/* Section Header */}
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          dir={language === 'ar' ? 'rtl' : 'ltr'}
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-white">
            {language === 'en' ? (
              <>Contact <span className="text-neon-primary">Us</span></>
            ) : (
              <>اتصل <span className="text-neon-primary">بنا</span></>
            )}
          </h2>
          <div className="w-24 h-1 bg-neon-primary animate-neon-pulse mx-auto mb-6"></div>
          <p className="text-gray-300 max-w-2xl mx-auto">
            {t('contact.subtitle')}
          </p>
        </motion.div>

        {/* Contact Information */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="max-w-2xl mx-auto"
          dir={language === 'ar' ? 'rtl' : 'ltr'}
        >
          <div className="glass border border-neon-primary/20 rounded-lg p-6 mb-8 shadow-neon">
            <p className="text-gray-300 mb-6 text-center leading-relaxed">
              {language === 'en' ? (
                "Ready to transform your store? Connect with us through any of these channels:"
              ) : (
                "جاهز لتحويل متجرك؟ تواصل معنا عبر أي من هذه القنوات:"
              )}
            </p>
            
            <div className="space-y-6">
              <a href="tel:+212631808007" className="flex items-center p-4 bg-dark-primary/30 rounded-lg hover:bg-neon-primary/10 transition-colors">
                <div className="w-12 h-12 rounded-full bg-neon-primary/10 flex items-center justify-center mr-4">
                  <Phone className="text-neon-primary" size={24} />
                </div>
                <div>
                  <p className="text-gray-400 text-sm">{t('contact.callUs')}</p>
                  <p className="text-gray-200 font-medium text-lg">+212 631 808 007</p>
                </div>
              </a>
              
              <a href="https://wa.me/212631808007" className="flex items-center p-4 bg-dark-primary/30 rounded-lg hover:bg-neon-primary/10 transition-colors group">
                <div className="w-12 h-12 rounded-full bg-neon-primary/10 flex items-center justify-center mr-4 group-hover:animate-neon-pulse">
                  <FaWhatsapp className="text-neon-primary" size={24} />
                </div>
                <div>
                  <p className="text-gray-400 text-sm">{t('contact.whatsapp')}</p>
                  <p className="text-gray-200 font-medium">{t('contact.chatWithUs')}</p>
                </div>
              </a>
              
              <a href="https://instagram.com/sd.creators" className="flex items-center p-4 bg-dark-primary/30 rounded-lg hover:bg-neon-primary/10 transition-colors group">
                <div className="w-12 h-12 rounded-full bg-neon-primary/10 flex items-center justify-center mr-4 group-hover:animate-neon-pulse">
                  <Instagram className="text-neon-primary" size={24} />
                </div>
                <div>
                  <p className="text-gray-400 text-sm">{t('contact.instagram')}</p>
                  <p className="text-gray-200 font-medium">@sd.creators</p>
                </div>
              </a>
            </div>
          </div>
          
          {/* Direct Call Button */}
          <div className="text-center mt-8">
            <a 
              href="tel:+212631808007" 
              className="inline-flex items-center px-6 py-4 bg-neon-primary hover:bg-neon-primary/80 text-gray-900 font-medium rounded-md shadow-neon transition-all text-lg"
            >
              <Phone className="mr-2" size={20} />
              +212 631 808 007
            </a>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
