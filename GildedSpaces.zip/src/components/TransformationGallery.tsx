import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useLanguage } from '../context/LanguageContext';
import BeforeAfterSlider from './BeforeAfterSlider';
import { ChevronLeft, ChevronRight } from 'lucide-react';

// Sample transformation data with before/after images
const transformations = [
  {
    id: 1,
    title: "Clothing Store Renovation",
    description: "Complete transformation with custom bardage and premium flooring",
    before: "https://mocha-cdn.com/0197a412-6faa-7f2a-8be7-de851ca42177/IMG_0588.jpeg",
    after: "https://mocha-cdn.com/0197a412-6faa-7f2a-8be7-de851ca42177/IMG_2392.jpeg",
    arabic: {
      title: "تجديد متجر ملابس",
      description: "تحول كامل مع كسوة خشب مخصصة وأرضيات فاخرة"
    }
  },
  {
    id: 2,
    title: "Retail Display Wall",
    description: "Enhanced product visibility with custom wall treatments",
    before: "https://mocha-cdn.com/0197a412-6faa-7f2a-8be7-de851ca42177/IMG_0945.jpeg",
    after: "https://mocha-cdn.com/0197a412-6faa-7f2a-8be7-de851ca42177/IMG_1021.jpeg",
    arabic: {
      title: "جدار عرض للبيع بالتجزئة",
      description: "تحسين رؤية المنتج مع معالجات جدارية مخصصة"
    }
  },
  {
    id: 3,
    title: "Boutique Interior",
    description: "Elegant placo plâtre ceiling and premium wall finishes",
    before: "https://mocha-cdn.com/0197a412-6faa-7f2a-8be7-de851ca42177/IMG_2339.jpeg",
    after: "https://mocha-cdn.com/0197a412-6faa-7f2a-8be7-de851ca42177/IMG_2392.jpeg",
    arabic: {
      title: "تصميم داخلي للبوتيك",
      description: "سقف جبس أنيق وتشطيبات جدران فاخرة"
    }
  }
];

export default function TransformationGallery() {
  const { language } = useLanguage();
  const isArabic = language === 'ar';
  const [activeIndex, setActiveIndex] = useState(0);
  
  const nextTransformation = () => {
    setActiveIndex((prevIndex) => (prevIndex + 1) % transformations.length);
  };
  
  const prevTransformation = () => {
    setActiveIndex((prevIndex) => (prevIndex - 1 + transformations.length) % transformations.length);
  };

  const activeTransformation = transformations[activeIndex];
  const currentItem = isArabic ? { ...activeTransformation, ...activeTransformation.arabic } : activeTransformation;

  return (
    <section id="transformations" className="py-20 bg-dark-secondary relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-20 left-1/4 w-64 h-64 bg-neon-primary/5 rounded-full blur-3xl"></div>
        <div className="absolute bottom-40 right-1/4 w-72 h-72 bg-neon-primary/10 rounded-full blur-3xl"></div>
        {/* Grid overlay */}
        <div className="absolute inset-0 opacity-5" 
             style={{ 
               backgroundImage: 'linear-gradient(to right, #00f2ff 1px, transparent 1px), linear-gradient(to bottom, #00f2ff 1px, transparent 1px)',
               backgroundSize: '40px 40px' 
             }}>
        </div>
      </div>
      
      <div className="container mx-auto px-4 md:px-6 relative z-10">
        {/* Section Header */}
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          dir={isArabic ? 'rtl' : 'ltr'}
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-white">
            {isArabic ? (
              <>تحولات <span className="text-neon-primary">مذهلة</span></>
            ) : (
              <>Amazing <span className="text-neon-primary">Transformations</span></>
            )}
          </h2>
          <div className="w-24 h-1 bg-neon-primary animate-neon-pulse mx-auto mb-6"></div>
          <p className="text-gray-300 max-w-2xl mx-auto">
            {isArabic ? 
              "شاهد التحول الكامل للمتاجر من خلال خدماتنا. حرك شريط التمرير لمقارنة الصور قبل وبعد." : 
              "See the complete transformation of shops through our services. Slide to compare before and after."}
          </p>
        </motion.div>

        {/* Enhanced Before/After Section */}
        <div className="max-w-5xl mx-auto">
          {/* Navigation Controls */}
          <div className="flex justify-between items-center mb-8">
            <motion.button
              onClick={prevTransformation}
              className="p-3 rounded-full bg-dark-primary border border-neon-primary/30 text-neon-primary hover:bg-neon-primary hover:text-gray-900 transition-all"
              whileHover={{ scale: 1.1, boxShadow: '0 0 15px rgba(0, 242, 255, 0.5)' }}
              whileTap={{ scale: 0.9 }}
              aria-label={isArabic ? "التحول السابق" : "Previous transformation"}
            >
              <ChevronLeft size={24} />
            </motion.button>
            
            <div className="text-center" dir={isArabic ? 'rtl' : 'ltr'}>
              <motion.h3 
                key={`title-${activeIndex}`}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="text-2xl font-semibold text-white mb-2"
              >
                {currentItem.title}
              </motion.h3>
              <motion.p 
                key={`desc-${activeIndex}`}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="text-gray-300"
              >
                {currentItem.description}
              </motion.p>
            </div>
            
            <motion.button
              onClick={nextTransformation}
              className="p-3 rounded-full bg-dark-primary border border-neon-primary/30 text-neon-primary hover:bg-neon-primary hover:text-gray-900 transition-all"
              whileHover={{ scale: 1.1, boxShadow: '0 0 15px rgba(0, 242, 255, 0.5)' }}
              whileTap={{ scale: 0.9 }}
              aria-label={isArabic ? "التحول التالي" : "Next transformation"}
            >
              <ChevronRight size={24} />
            </motion.button>
          </div>
          
          {/* Transformation Slider */}
          <motion.div
            className="relative rounded-xl overflow-hidden shadow-2xl"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
          >
            <AnimatePresence mode="wait">
              <motion.div
                key={activeIndex}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.5 }}
              >
                <BeforeAfterSlider 
                  beforeImage={activeTransformation.before} 
                  afterImage={activeTransformation.after}
                />
              </motion.div>
            </AnimatePresence>
            
            {/* Pagination Indicators */}
            <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
              {transformations.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setActiveIndex(index)}
                  className={`w-3 h-3 rounded-full transition-all ${
                    index === activeIndex 
                      ? 'bg-neon-primary w-6' 
                      : 'bg-gray-500 hover:bg-gray-400'
                  }`}
                  aria-label={`Go to transformation ${index + 1}`}
                />
              ))}
            </div>
          </motion.div>
        </div>
        
        {/* Enhanced Call to Action */}
        <motion.div 
          className="text-center mt-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.3 }}
        >
          <div className="glass max-w-2xl mx-auto p-8 rounded-xl border border-neon-primary/20">
            <h3 className="text-xl font-bold text-white mb-4">
              {isArabic ? "هل ترغب في تحويل متجرك؟" : "Want to transform your shop?"}
            </h3>
            <p className="text-gray-300 mb-6">
              {isArabic 
                ? "اتصل بنا اليوم للحصول على استشارة مجانية ومعرفة كيف يمكننا تحويل مساحتك التجارية." 
                : "Contact us today for a free consultation and discover how we can transform your commercial space."
              }
            </p>
            <motion.a 
              href="https://wa.me/212631808007" 
              className="inline-flex items-center px-8 py-3 bg-neon-primary hover:bg-neon-primary/80 text-gray-900 font-medium rounded-md shadow-neon transition-all"
              whileHover={{ scale: 1.05, boxShadow: '0 0 20px rgba(0, 242, 255, 0.6)' }}
              whileTap={{ scale: 0.95 }}
            >
              <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 24 24" className={`w-5 h-5 ${isArabic ? 'ml-2' : 'mr-2'}`}>
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
              </svg>
              {isArabic ? "احصل على تحول مماثل لمتجرك" : "Get a Similar Transformation"}
            </motion.a>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
