import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Globe, Menu, X } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { language, setLanguage, t } = useLanguage();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleLanguage = () => {
    setLanguage(language === 'en' ? 'ar' : 'en');
  };

  return (
    <motion.nav
      className={`fixed w-full z-50 transition-all duration-300 ${
        isScrolled ? 'glass py-3 shadow-neon' : 'bg-transparent py-5'
      }`}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <a href="#" className="text-2xl font-bold text-white">
              <span className="text-neon-primary">Sd</span>creators
            </a>
          </div>

          {/* Language Toggle */}
          <button 
            onClick={toggleLanguage}
            className="absolute left-1/2 transform -translate-x-1/2 bg-neon-primary/10 hover:bg-neon-primary/20 text-neon-primary p-2 rounded-full transition-all"
            aria-label="Toggle language"
          >
            <Globe size={20} />
            <span className="sr-only">
              {language === 'en' ? 'Switch to Arabic' : 'Switch to English'}
            </span>
          </button>

          {/* Desktop Menu */}
          <div className={`hidden md:flex items-center space-x-8 ${language === 'ar' ? 'rtl:space-x-reverse' : ''}`}>
            <a href="#services" className="text-gray-300 hover:text-neon-primary transition-colors">{t('nav.services')}</a>
            <a href="#transformations" className="text-gray-300 hover:text-neon-primary transition-colors">{t('nav.transformations')}</a>
            <a href="#benefits" className="text-gray-300 hover:text-neon-primary transition-colors">{t('nav.benefits')}</a>
            <a href="#portfolio" className="text-gray-300 hover:text-neon-primary transition-colors">{t('nav.ourWork')}</a>
            <a href="#pricing" className="text-gray-300 hover:text-neon-primary transition-colors">{t('nav.pricing')}</a>
            <a href="#contact" className="px-5 py-2 bg-neon-primary text-gray-900 hover:bg-neon-primary/80 transition-all rounded-md shadow-neon">{t('nav.contactUs')}</a>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button 
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-white p-2"
            >
              {isMenuOpen ? <X size={24} className="text-neon-primary" /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <motion.div 
          className="md:hidden glass border-t border-neon-primary/20"
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          transition={{ duration: 0.3 }}
        >
          <div className="container mx-auto px-4 py-4 flex flex-col space-y-4">
            <a 
              href="#services" 
              className="text-gray-300 hover:text-neon-primary transition-colors py-2 border-b border-gray-700"
              onClick={() => setIsMenuOpen(false)}
            >
              {t('nav.services')}
            </a>
            <a 
              href="#transformations" 
              className="text-gray-300 hover:text-neon-primary transition-colors py-2 border-b border-gray-700"
              onClick={() => setIsMenuOpen(false)}
            >
              {t('nav.transformations')}
            </a>
            <a 
              href="#benefits" 
              className="text-gray-300 hover:text-neon-primary transition-colors py-2 border-b border-gray-700"
              onClick={() => setIsMenuOpen(false)}
            >
              {t('nav.benefits')}
            </a>
            <a 
              href="#portfolio" 
              className="text-gray-300 hover:text-neon-primary transition-colors py-2 border-b border-gray-700"
              onClick={() => setIsMenuOpen(false)}
            >
              {t('nav.ourWork')}
            </a>
            <a 
              href="#pricing" 
              className="text-gray-300 hover:text-neon-primary transition-colors py-2 border-b border-gray-700"
              onClick={() => setIsMenuOpen(false)}
            >
              {t('nav.pricing')}
            </a>
            <a 
              href="#contact" 
              className="text-center px-5 py-2 bg-neon-primary text-gray-900 hover:bg-neon-primary/80 transition-all rounded-md shadow-neon"
              onClick={() => setIsMenuOpen(false)}
            >
              {t('nav.contactUs')}
            </a>
          </div>
        </motion.div>
      )}
    </motion.nav>
  );
}
