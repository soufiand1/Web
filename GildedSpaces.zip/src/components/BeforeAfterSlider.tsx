import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useLanguage } from '../context/LanguageContext';

interface BeforeAfterSliderProps {
  beforeImage: string;
  afterImage: string;
  beforeLabel?: string;
  afterLabel?: string;
}

export default function BeforeAfterSlider({ 
  beforeImage, 
  afterImage, 
  beforeLabel = "Before", 
  afterLabel = "After" 
}: BeforeAfterSliderProps) {
  const [sliderPosition, setSliderPosition] = useState(50);
  const [isDragging, setIsDragging] = useState(false);
  const [showHint, setShowHint] = useState(true);
  const containerRef = useRef<HTMLDivElement>(null);
  const { language } = useLanguage();

  const handleMouseDown = () => {
    setIsDragging(true);
    setShowHint(false); // Hide hint when user starts interacting
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleMouseMove = (e: MouseEvent) => {
    if (isDragging && containerRef.current) {
      const rect = containerRef.current.getBoundingClientRect();
      const x = Math.max(0, Math.min(e.clientX - rect.left, rect.width));
      const percentage = Math.max(0, Math.min(100, (x / rect.width) * 100));
      setSliderPosition(percentage);
    }
  };

  const handleTouchMove = (e: TouchEvent) => {
    if (isDragging && containerRef.current) {
      const rect = containerRef.current.getBoundingClientRect();
      const touch = e.touches[0];
      const x = Math.max(0, Math.min(touch.clientX - rect.left, rect.width));
      const percentage = Math.max(0, Math.min(100, (x / rect.width) * 100));
      setSliderPosition(percentage);
    }
  };

  useEffect(() => {
    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
    document.addEventListener('touchmove', handleTouchMove);
    document.addEventListener('touchend', handleMouseUp);

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
      document.removeEventListener('touchmove', handleTouchMove);
      document.removeEventListener('touchend', handleMouseUp);
    };
  }, [isDragging]);

  // Auto-hint timer
  useEffect(() => {
    const timer = setTimeout(() => {
      // Reset hint after 5 seconds
      setShowHint(false);
    }, 5000);
    
    return () => clearTimeout(timer);
  }, []);

  // Determine labels based on language
  const before = language === 'ar' ? 'قبل' : beforeLabel;
  const after = language === 'ar' ? 'بعد' : afterLabel;

  return (
    <div 
      className="relative w-full h-[400px] overflow-hidden rounded-lg shadow-neon group"
      ref={containerRef}
    >
      {/* Before image (full width) */}
      <div className="absolute inset-0">
        <img 
          src={beforeImage} 
          alt="Before" 
          className="w-full h-full object-cover"
        />
        {/* Before label */}
        <motion.div 
          className="absolute top-4 left-4 bg-gray-900/80 text-white px-3 py-1 rounded-md text-sm font-medium"
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          {before}
        </motion.div>
      </div>

      {/* After image (clipped) */}
      <div 
        className="absolute inset-0 overflow-hidden"
        style={{ width: `${sliderPosition}%` }}
      >
        <img 
          src={afterImage} 
          alt="After" 
          className="absolute top-0 left-0 w-full h-full object-cover"
        />
        {/* After label */}
        <motion.div 
          className="absolute top-4 right-4 bg-neon-primary text-gray-900 px-3 py-1 rounded-md text-sm font-medium"
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          {after}
        </motion.div>
      </div>

      {/* Slider handle */}
      <motion.div 
        className="absolute top-0 bottom-0 w-1 bg-neon-primary cursor-ew-resize"
        style={{ left: `${sliderPosition}%` }}
        onMouseDown={handleMouseDown}
        onTouchStart={handleMouseDown}
        initial={{ height: "90%" }}
        whileHover={{ height: "100%", boxShadow: "0 0 15px rgba(0, 242, 255, 0.8)" }}
        animate={{ 
          boxShadow: isDragging 
            ? "0 0 20px rgba(0, 242, 255, 0.8)" 
            : "0 0 10px rgba(0, 242, 255, 0.5)" 
        }}
      >
        <motion.div 
          className="absolute top-1/2 left-1/2 w-8 h-8 rounded-full bg-neon-primary shadow-neon flex items-center justify-center"
          style={{ translateX: "-50%", translateY: "-50%" }}
          whileHover={{ scale: 1.2 }}
          whileTap={{ scale: 0.9 }}
          animate={{ 
            boxShadow: isDragging 
              ? "0 0 20px rgba(0, 242, 255, 0.8)" 
              : "0 0 10px rgba(0, 242, 255, 0.5)" 
          }}
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M8 5L3 10L8 15" stroke="#121212" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M16 5L21 10L16 15" stroke="#121212" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </motion.div>
      </motion.div>

      {/* Interactive hint - only show initially */}
      <AnimatePresence>
        {showHint && (
          <motion.div
            className="absolute top-1/2 left-1/2 transform -translate-y-1/2 flex flex-col items-center justify-center"
            style={{ left: `${sliderPosition}%`, translateX: "-50%" }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.div
              className="bg-gray-900/80 text-white px-3 py-2 rounded-lg text-sm mb-2 whitespace-nowrap"
              animate={{ y: [0, -5, 0] }}
              transition={{ repeat: Infinity, duration: 1.5 }}
            >
              {language === 'ar' ? 'اسحب للمقارنة' : 'Slide to compare'}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
      
      {/* Multiple pulse effects for interactive hint */}
      <AnimatePresence>
        {showHint && (
          <>
            <motion.div 
              className="absolute top-1/2 left-1/2 w-16 h-16 rounded-full border-2 border-neon-primary"
              initial={{ opacity: 0.7, scale: 0.3 }}
              animate={{ opacity: 0, scale: 1.5 }}
              transition={{ 
                repeat: Infinity, 
                duration: 2,
                repeatDelay: 0.5
              }}
              style={{ 
                transform: 'translate(-50%, -50%)',
                left: `${sliderPosition}%`
              }}
              exit={{ opacity: 0 }}
            />
            <motion.div 
              className="absolute top-1/2 left-1/2 w-16 h-16 rounded-full border-2 border-neon-primary"
              initial={{ opacity: 0.7, scale: 0.3 }}
              animate={{ opacity: 0, scale: 1.5 }}
              transition={{ 
                repeat: Infinity, 
                duration: 2,
                delay: 0.5,
                repeatDelay: 0.5
              }}
              style={{ 
                transform: 'translate(-50%, -50%)',
                left: `${sliderPosition}%`
              }}
              exit={{ opacity: 0 }}
            />
          </>
        )}
      </AnimatePresence>

      {/* Glass effect overlay for enhanced visuals */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none"></div>
    </div>
  );
}
