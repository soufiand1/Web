import { useState, useRef, useEffect } from 'react';
import { motion, useMotionValue, useTransform } from 'framer-motion';
import { useLanguage } from '../context/LanguageContext';

// Sample project data
const projectData = {
  title: "Luxury Boutique Renovation",
  titlear: "تجديد بوتيك فاخر",
  description: "Complete transformation including custom bardage, premium lighting, and specialized display systems.",
  descriptionar: "تحول كامل يشمل كسوة خشب مخصصة وإضاءة فاخرة وأنظمة عرض متخصصة.",
  images: [
    "https://mocha-cdn.com/0197a412-6faa-7f2a-8be7-de851ca42177/IMG_0588.jpeg",
    "https://mocha-cdn.com/0197a412-6faa-7f2a-8be7-de851ca42177/IMG_0945.jpeg",
    "https://mocha-cdn.com/0197a412-6faa-7f2a-8be7-de851ca42177/IMG_1021.jpeg",
    "https://mocha-cdn.com/0197a412-6faa-7f2a-8be7-de851ca42177/IMG_2339.jpeg",
    "https://mocha-cdn.com/0197a412-6faa-7f2a-8be7-de851ca42177/IMG_2392.jpeg"
  ]
};

export default function ProjectViewer3D() {
  const { language } = useLanguage();
  const isArabic = language === 'ar';
  const [currentIndex, setCurrentIndex] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);
  const [isDragging, setIsDragging] = useState(false);

  // Motion values for dragging
  const x = useMotionValue(0);
  const rotateY = useTransform(x, [-300, 300], [30, -30]);
  const scale = useTransform(x, [-300, 0, 300], [0.9, 1, 0.9]);
  const brightness = useTransform(x, [-300, 0, 300], [0.7, 1, 0.7]);

  // Effect to handle keydown events for navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft') {
        setCurrentIndex(prev => (prev - 1 + projectData.images.length) % projectData.images.length);
      } else if (e.key === 'ArrowRight') {
        setCurrentIndex(prev => (prev + 1) % projectData.images.length);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Drag handlers
  const handleDragStart = () => {
    setIsDragging(true);
  };

  const handleDragEnd = () => {
    setIsDragging(false);
    
    // If dragged far enough, change the image
    const currentX = x.get();
    if (currentX > 100) {
      setCurrentIndex(prev => (prev - 1 + projectData.images.length) % projectData.images.length);
    } else if (currentX < -100) {
      setCurrentIndex(prev => (prev + 1) % projectData.images.length);
    }
    
    // Reset position
    x.set(0);
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="text-center mb-6" dir={isArabic ? 'rtl' : 'ltr'}>
        <h3 className="text-2xl md:text-3xl font-bold text-white mb-2">
          {isArabic ? projectData.titlear : projectData.title}
        </h3>
        <p className="text-gray-300">
          {isArabic ? projectData.descriptionar : projectData.description}
        </p>
      </div>

      <div className="relative h-[400px] md:h-[500px] perspective" ref={containerRef}>
        {/* 3D Image Container */}
        <motion.div
          className="w-full h-full relative cursor-grab active:cursor-grabbing"
          style={{
            rotateY,
            scale,
            filter: `brightness(${brightness})`,
            transformStyle: 'preserve-3d'
          }}
          drag="x"
          dragConstraints={{ left: 0, right: 0 }}
          dragElastic={0.1}
          onDragStart={handleDragStart}
          onDragEnd={handleDragEnd}
          whileTap={{ cursor: 'grabbing' }}
        >
          {/* Main Image */}
          <motion.div
            className="absolute inset-0 rounded-xl overflow-hidden shadow-2xl border border-neon-primary/30"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
            style={{ transformStyle: 'preserve-3d', backfaceVisibility: 'hidden' }}
          >
            <motion.img
              key={currentIndex}
              src={projectData.images[currentIndex]}
              alt={`Project view ${currentIndex + 1}`}
              className="w-full h-full object-cover"
              initial={{ scale: 1.1 }}
              animate={{ scale: 1 }}
              transition={{ duration: 0.7 }}
            />
            
            {/* Reflective surface effect */}
            <div className="absolute inset-0 bg-gradient-to-b from-transparent to-dark-primary/40 pointer-events-none" />
            
            {/* Glare effect */}
            <motion.div 
              className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent pointer-events-none"
              style={{ opacity: useTransform(x, [-300, 0, 300], [0, 0.1, 0]) }}
            />
          </motion.div>
          
          {/* Navigation hint */}
          {!isDragging && (
            <div className="absolute inset-0 flex items-center justify-between pointer-events-none px-4">
              <motion.div 
                className="w-10 h-10 rounded-full bg-dark-primary/70 flex items-center justify-center text-white"
                initial={{ opacity: 0 }}
                animate={{ opacity: 0.6, x: [0, -10, 0] }}
                transition={{ repeat: Infinity, duration: 2 }}
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
              </motion.div>
              <motion.div 
                className="w-10 h-10 rounded-full bg-dark-primary/70 flex items-center justify-center text-white"
                initial={{ opacity: 0 }}
                animate={{ opacity: 0.6, x: [0, 10, 0] }}
                transition={{ repeat: Infinity, duration: 2 }}
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </motion.div>
            </div>
          )}
        </motion.div>
        
        {/* Image indicators */}
        <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2 z-10">
          {projectData.images.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentIndex(idx)}
              className={`w-2 h-2 rounded-full transition-all duration-300 ${
                idx === currentIndex 
                  ? 'bg-neon-primary w-6' 
                  : 'bg-gray-500 hover:bg-gray-400'
              }`}
              aria-label={`View image ${idx + 1}`}
            />
          ))}
        </div>
        
        {/* Perspective shadow */}
        <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-4/5 h-4 bg-neon-primary/20 filter blur-xl rounded-full" />
      </div>
      
      <div className="text-center mt-6">
        <p className="text-gray-400 text-sm">
          {isArabic ? "اسحب للتنقل بين الصور" : "Drag to navigate between images"}
        </p>
      </div>
    </div>
  );
}
