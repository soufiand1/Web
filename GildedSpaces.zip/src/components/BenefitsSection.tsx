import { motion } from 'framer-motion';
import { Banknote, Clock, ThumbsUp, TrendingUp } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

const benefits = [
  {
    icon: <ThumbsUp size={24} className="text-neon-primary" />,
    title: "Premium Shop Finishes",
    description: "Elevate your store with professional stall walls, bardage, and papier peint that create a memorable shopping environment."
  },
  {
    icon: <TrendingUp size={24} className="text-neon-primary" />,
    title: "Increased Customer Engagement",
    description: "Our custom wall designs and strategic floor layouts help showcase your products effectively, boosting sales."
  },
  {
    icon: <Clock size={24} className="text-neon-primary" />,
    title: "Durable Commercial Solutions",
    description: "All materials and installations are selected specifically for high-traffic commercial environments for long-term performance."
  },
  {
    icon: <Banknote size={24} className="text-neon-primary" />,
    title: "Competitive Advantage",
    description: "Stand out from neighboring shops with custom-designed bardage, premium parquet, and professional placo plâtre finishes."
  }
];

export default function BenefitsSection() {
  const { language, t } = useLanguage();
  return (
    <section id="benefits" className="py-20 bg-dark-primary">
      <div className="container mx-auto px-4 md:px-6">
        {/* Section Header */}
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-white" dir={language === 'ar' ? 'rtl' : 'ltr'}>
            {language === 'en' ? (
              <>Benefits for <span className="text-neon-primary">Store Owners</span></>
            ) : (
              <><span className="text-neon-primary">مميزات</span> لأصحاب المتاجر</>
            )}
          </h2>
          <div className="w-24 h-1 bg-neon-primary animate-neon-pulse mx-auto mb-6"></div>
          <p className="text-gray-300 max-w-2xl mx-auto" dir={language === 'ar' ? 'rtl' : 'ltr'}>
            {t('benefits.subtitle')}
          </p>
        </motion.div>

        {/* Benefits Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {benefits.map((benefit, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="glass p-6 rounded-lg shadow-neon flex"
            >
              <div className="mr-4 bg-neon-primary/10 p-3 rounded-full h-fit">
                {benefit.icon}
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2 text-white" dir={language === 'ar' ? 'rtl' : 'ltr'}>
                  {language === 'en' ? benefit.title : 
                    index === 0 ? "تشطيبات متجر فاخرة" : 
                    index === 1 ? "زيادة تفاعل العملاء" :
                    index === 2 ? "حلول تجارية متينة" :
                    "تميز عن المنافسين"}
                </h3>
                <p className="text-gray-300" dir={language === 'ar' ? 'rtl' : 'ltr'}>
                  {language === 'en' ? benefit.description : 
                    index === 0 ? "جدران عالية الجودة، كسوة خشب، وورق حائط تخلق بيئة تسوق جذابة." : 
                    index === 1 ? "تصاميم مخصصة تعرض منتجاتك بفعالية وتعزز المبيعات." :
                    index === 2 ? "مواد مختارة للمساحات التجارية ذات الحركة العالية، مما يضمن الأداء على المدى الطويل." :
                    "كسوة خشب مخصصة، أرضيات فاخرة، وتشطيبات احترافية تجعل متجرك فريداً."}
                </p>
              </div>
            </motion.div>
          ))}
        </div>

        {/* CTA Button */}
        <motion.div 
          className="text-center mt-12"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.3 }}
        >
          <a 
            href="tel:+212631808007" 
            className="inline-flex items-center px-6 py-3 bg-neon-primary hover:bg-neon-primary/80 text-gray-900 font-medium rounded-md shadow-neon transition-all"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
              <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
            </svg>
            Call +212 631 808 007
          </a>
        </motion.div>
      </div>
    </section>
  );
}
