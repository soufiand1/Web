import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useLanguage } from '../context/LanguageContext';

const services = [
  {
    id: 'bardage',
    name: 'Bardage',
    namear: 'كسوة خشب',
    description: 'Premium wood paneling solutions that combine aesthetics with durability for your shop interior and exterior.',
    descriptionar: 'حلول كسوة خشب فاخرة تجمع بين الجماليات والمتانة لتصميم متجرك الداخلي والخارجي.',
    image: 'https://mocha-cdn.com/0197a412-6faa-7f2a-8be7-de851ca42177/IMG_0945.jpeg',
    details: [
      { title: 'Materials', titlear: 'المواد', content: 'Premium woods, composite materials, eco-friendly options', contentar: 'أخشاب فاخرة، مواد مركبة، خيارات صديقة للبيئة' },
      { title: 'Applications', titlear: 'التطبيقات', content: 'Interior walls, façades, decorative elements', contentar: 'الجدران الداخلية، الواجهات، العناصر الزخرفية' },
      { title: 'Benefits', titlear: 'الفوائد', content: 'Enhanced aesthetics, improved insulation, brand image reinforcement', contentar: 'تحسين الجماليات، عزل أفضل، تعزيز صورة العلامة التجارية' }
    ]
  },
  {
    id: 'placoplatre',
    name: 'Placo Plâtre',
    namear: 'جبس بورد',
    description: 'Versatile drywall solutions that create stunning ceiling designs and perfect wall finishes for your commercial space.',
    descriptionar: 'حلول متعددة الاستخدامات من الجبس بورد التي تخلق تصاميم سقف مذهلة وتشطيبات جدران مثالية لمساحتك التجارية.',
    image: 'https://mocha-cdn.com/0197a412-6faa-7f2a-8be7-de851ca42177/IMG_2339.jpeg',
    details: [
      { title: 'Designs', titlear: 'التصاميم', content: 'Custom ceilings, curved walls, integrated lighting solutions', contentar: 'أسقف مخصصة، جدران منحنية، حلول إضاءة متكاملة' },
      { title: 'Features', titlear: 'المميزات', content: 'Acoustic optimization, moisture resistance, fire protection', contentar: 'تحسين الصوتيات، مقاومة الرطوبة، الحماية من الحريق' },
      { title: 'Installation', titlear: 'التركيب', content: 'Precision fitting, seamless finishes, rapid execution', contentar: 'تركيب دقيق، تشطيبات سلسة، تنفيذ سريع' }
    ]
  },
  {
    id: 'papierpeint',
    name: 'Papier Peint',
    namear: 'ورق الحائط',
    description: 'Transform your shop ambiance with our premium wallpaper collections that make a lasting impression on customers.',
    descriptionar: 'حوّل أجواء متجرك مع مجموعات ورق الحائط الفاخرة لدينا التي تترك انطباعًا دائمًا لدى العملاء.',
    image: 'https://mocha-cdn.com/0197a412-6faa-7f2a-8be7-de851ca42177/IMG_1021.jpeg',
    details: [
      { title: 'Collections', titlear: 'المجموعات', content: 'Designer patterns, textured finishes, custom brand designs', contentar: 'أنماط من المصمم، تشطيبات بارزة، تصاميم مخصصة للعلامة التجارية' },
      { title: 'Qualities', titlear: 'الخصائص', content: 'Stain-resistant, washable, commercial-grade durability', contentar: 'مقاوم للبقع، قابل للغسل، متانة بدرجة تجارية' },
      { title: 'Applications', titlear: 'التطبيقات', content: 'Feature walls, complete interiors, brand zones', contentar: 'جدران مميزة، تصاميم داخلية كاملة، مناطق العلامة التجارية' }
    ]
  },
  {
    id: 'shopwalls',
    name: 'Shop Walls',
    namear: 'جدران المتاجر',
    description: 'Specialized wall systems designed specifically for retail environments to maximize product display and customer flow.',
    descriptionar: 'أنظمة جدران متخصصة مصممة خصيصًا لبيئات البيع بالتجزئة لتعظيم عرض المنتجات وتدفق العملاء.',
    image: 'https://mocha-cdn.com/0197a412-6faa-7f2a-8be7-de851ca42177/IMG_0588.jpeg',
    details: [
      { title: 'Systems', titlear: 'الأنظمة', content: 'Modular displays, slatwall systems, integrated shelving', contentar: 'عروض نمطية، أنظمة الجدران المشقوقة، رفوف متكاملة' },
      { title: 'Customization', titlear: 'التخصيص', content: 'Brand-specific colors, illuminated features, interactive elements', contentar: 'ألوان خاصة بالعلامة التجارية، ميزات مضاءة، عناصر تفاعلية' },
      { title: 'Optimization', titlear: 'التحسين', content: 'Space efficiency, product visibility, customer journey enhancement', contentar: 'كفاءة المساحة، رؤية المنتج، تحسين رحلة العميل' }
    ]
  }
];

export default function InteractiveServiceExplorer() {
  const { language } = useLanguage();
  const [activeService, setActiveService] = useState(services[0]);
  const [activeDetail, setActiveDetail] = useState(0);
  const isArabic = language === 'ar';

  return (
    <div className="glass rounded-xl overflow-hidden border border-neon-primary/20 max-w-5xl mx-auto">
      <div className="grid grid-cols-1 md:grid-cols-2">
        {/* Service image side */}
        <motion.div 
          className="relative h-[300px] md:h-auto overflow-hidden"
          layout
        >
          <AnimatePresence mode="wait">
            <motion.div
              key={activeService.id}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.5 }}
              className="absolute inset-0"
            >
              <motion.img 
                src={activeService.image} 
                alt={isArabic ? activeService.namear : activeService.name}
                className="w-full h-full object-cover"
                initial={{ scale: 1.2 }}
                animate={{ scale: 1 }}
                transition={{ duration: 1.5 }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-dark-primary via-transparent to-transparent" />
            </motion.div>
          </AnimatePresence>
          
          <div className="absolute bottom-0 left-0 right-0 p-6 z-10" dir={isArabic ? 'rtl' : 'ltr'}>
            <motion.h3 
              className="text-2xl font-bold text-white mb-2"
              layout
            >
              {isArabic ? activeService.namear : activeService.name}
            </motion.h3>
            <motion.p 
              className="text-gray-300 text-sm"
              layout
            >
              {isArabic ? activeService.descriptionar : activeService.description}
            </motion.p>
          </div>
        </motion.div>
        
        {/* Service details side */}
        <div className="p-6" dir={isArabic ? 'rtl' : 'ltr'}>
          {/* Service tabs */}
          <div className="flex flex-wrap gap-2 mb-6">
            {services.map((service) => (
              <motion.button
                key={service.id}
                onClick={() => {
                  setActiveService(service);
                  setActiveDetail(0);
                }}
                className={`px-3 py-1 rounded-full text-sm font-medium transition-all
                  ${activeService.id === service.id 
                    ? 'bg-neon-primary text-gray-900' 
                    : 'bg-dark-primary border border-neon-primary/30 text-gray-300'
                  }`}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                {isArabic ? service.namear : service.name}
              </motion.button>
            ))}
          </div>
          
          {/* Detail tabs */}
          <div className="flex mb-6 border-b border-gray-700">
            {activeService.details.map((detail, index) => (
              <motion.button
                key={index}
                onClick={() => setActiveDetail(index)}
                className={`px-4 py-2 font-medium text-sm relative
                  ${activeDetail === index 
                    ? 'text-neon-primary' 
                    : 'text-gray-400 hover:text-gray-300'
                  }`}
                whileHover={{ y: -2 }}
              >
                {isArabic ? detail.titlear : detail.title}
                {activeDetail === index && (
                  <motion.div 
                    className="absolute bottom-0 left-0 right-0 h-0.5 bg-neon-primary"
                    layoutId="activeDetailIndicator"
                  />
                )}
              </motion.button>
            ))}
          </div>
          
          {/* Detail content */}
          <AnimatePresence mode="wait">
            <motion.div
              key={`${activeService.id}-${activeDetail}`}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3 }}
              className="min-h-[150px]"
            >
              <h4 className="text-lg font-semibold text-white mb-3">
                {isArabic 
                  ? activeService.details[activeDetail].titlear 
                  : activeService.details[activeDetail].title}
              </h4>
              <p className="text-gray-300 leading-relaxed">
                {isArabic 
                  ? activeService.details[activeDetail].contentar 
                  : activeService.details[activeDetail].content}
              </p>
              
              <motion.button
                className="mt-6 inline-flex items-center text-neon-primary hover:text-white transition-colors"
                whileHover={{ x: isArabic ? -5 : 5 }}
              >
                {isArabic ? "احصل على استشارة" : "Get consultation"}
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  className={`w-4 h-4 ${isArabic ? 'mr-2 rotate-180' : 'ml-2'}`} 
                  viewBox="0 0 20 20" 
                  fill="currentColor"
                >
                  <path fillRule="evenodd" d="M10.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L12.586 11H5a1 1 0 110-2h7.586l-2.293-2.293a1 1 0 010-1.414z" clipRule="evenodd" />
                </svg>
              </motion.button>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
