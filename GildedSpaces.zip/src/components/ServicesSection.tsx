import { motion } from 'framer-motion';
import { Brush, Lightbulb, Sparkles } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

const services = [
  {
    icon: <Brush size={48} className="text-neon-primary" />,
    title: "Shop Interior Design",
    description: "Transform your store's appearance with our professional design services that blend functionality with aesthetic appeal.",
    features: ["Custom stall wall design", "Bardage installations", "Stylish papier peint", "Placo plâtre solutions"],
    arabic: {
      title: "تصميم داخلي للمتاجر",
      description: "حول مظهر متجرك بخدمات التصميم الاحترافية التي تجمع بين الوظائف العملية والجاذبية الجمالية.",
      features: ["تصميم جدران المتاجر المخصص", "تركيبات كسوة الخشب", "ورق حائط أنيق", "حلول الجبس"]
    }
  },
  {
    icon: <Lightbulb size={48} className="text-neon-primary" />,
    title: "Lighting & Flooring",
    description: "Enhance your products' appeal with strategic lighting and premium flooring solutions for the perfect shopping environment.",
    features: ["Strategic display lighting", "Premium parquet installation", "Energy-efficient options", "Custom floor patterns"],
    arabic: {
      title: "الإضاءة والأرضيات",
      description: "عزز جاذبية منتجاتك بإضاءة استراتيجية وحلول أرضيات فاخرة لبيئة تسوق مثالية.",
      features: ["إضاءة عرض استراتيجية", "تركيب باركيه فاخر", "خيارات موفرة للطاقة", "أنماط أرضيات مخصصة"]
    }
  },
  {
    icon: <Sparkles size={48} className="text-neon-primary" />,
    title: "Maintenance Services",
    description: "Maintain a pristine shopping environment with our regular maintenance packages, tailored to your store's specific needs.",
    features: ["Wall cleaning & repair", "Bardage maintenance", "Papier peint touch-ups", "Floor polishing"],
    arabic: {
      title: "خدمات الصيانة",
      description: "حافظ على بيئة تسوق نظيفة مع باقات الصيانة المنتظمة المصممة خصيصًا لاحتياجات متجرك المحددة.",
      features: ["تنظيف وإصلاح الجدران", "صيانة كسوة الخشب", "تحسينات ورق الحائط", "تلميع الأرضيات"]
    }
  }
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.2
    }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6 }
  }
};

export default function ServicesSection() {
  const { language } = useLanguage();
  const isArabic = language === 'ar';
  
  return (
    <section id="services" className="py-20 bg-dark-secondary relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-20 left-10 w-96 h-96 bg-neon-primary/5 rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 right-10 w-80 h-80 bg-neon-accent/5 rounded-full blur-3xl"></div>
        {/* Grid overlay */}
        <div className="absolute inset-0 opacity-5" 
             style={{ 
               backgroundImage: 'linear-gradient(to right, #00f2ff 1px, transparent 1px), linear-gradient(to bottom, #00f2ff 1px, transparent 1px)',
               backgroundSize: '40px 40px' 
             }}>
        </div>
      </div>
      
      <div className="container mx-auto px-4 md:px-6 relative z-10">
        {/* Section Header */}
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            dir={isArabic ? 'rtl' : 'ltr'}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-white">
              {isArabic ? (
                <><span className="text-neon-primary">خدماتنا</span></>
              ) : (
                <>Our <span className="text-neon-primary">Services</span></>
              )}
            </h2>
            <div className="w-24 h-1 bg-neon-primary animate-neon-pulse mx-auto mb-6"></div>
            <p className="text-gray-300 max-w-2xl mx-auto">
              {isArabic ? 
                "نقوم بتحويل مساحتك التجارية بتشطيبات احترافية تعكس هوية علامتك التجارية." : 
                "We transform your commercial space with professional finishes that reflect your brand."}
            </p>
          </motion.div>
        </div>
        
        {/* Services Grid */}
        <motion.div 
          className="grid grid-cols-1 md:grid-cols-3 gap-8"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
        >
          {services.map((service, index) => {
            const currentService = isArabic ? { ...service, ...service.arabic } : service;
            
            return (
              <motion.div 
                key={index}
                variants={itemVariants}
                className="glass p-8 rounded-lg shadow-neon group hover:shadow-neon transition-all duration-300"
                whileHover={{ 
                  y: -10, 
                  boxShadow: '0 0 20px rgba(0, 242, 255, 0.4), 0 0 30px rgba(251, 0, 255, 0.2)'
                }}
                dir={isArabic ? 'rtl' : 'ltr'}
              >
                <motion.div 
                  className="bg-neon-primary/10 rounded-full w-16 h-16 flex items-center justify-center mb-6 group-hover:bg-neon-primary/20 transition-all"
                  whileHover={{ scale: 1.1, rotate: 5 }}
                >
                  {service.icon}
                </motion.div>
                <h3 className="text-2xl font-semibold mb-4 text-white">{currentService.title}</h3>
                <p className="text-gray-300 mb-6">{currentService.description}</p>
                <ul className="space-y-3">
                  {currentService.features.map((feature, idx) => (
                    <motion.li 
                      key={idx} 
                      className="flex items-center text-gray-300"
                      initial={{ opacity: 0, x: isArabic ? 10 : -10 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: idx * 0.1 + 0.3 }}
                    >
                      <motion.span 
                        className={`w-2 h-2 bg-neon-primary rounded-full ${isArabic ? 'ml-2' : 'mr-2'} flex-shrink-0`}
                        animate={{ 
                          boxShadow: ['0 0 0px rgba(0, 242, 255, 0.5)', '0 0 5px rgba(0, 242, 255, 0.8)', '0 0 0px rgba(0, 242, 255, 0.5)']
                        }}
                        transition={{ duration: 2, repeat: Infinity, delay: idx * 0.2 }}
                      />
                      {feature}
                    </motion.li>
                  ))}
                </ul>
                
                {/* Learn More Button */}
                <motion.a
                  href="https://wa.me/212631808007"
                  className="inline-flex items-center mt-6 text-neon-primary hover:text-white transition-colors"
                  whileHover={{ x: isArabic ? -5 : 5 }}
                >
                  {isArabic ? "استعلم عن المزيد" : "Learn more"}
                  <svg 
                    xmlns="http://www.w3.org/2000/svg" 
                    className={`w-4 h-4 ${isArabic ? 'mr-1 rotate-180' : 'ml-1'}`} 
                    viewBox="0 0 20 20" 
                    fill="currentColor"
                  >
                    <path fillRule="evenodd" d="M10.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L12.586 11H5a1 1 0 110-2h7.586l-2.293-2.293a1 1 0 010-1.414z" clipRule="evenodd" />
                  </svg>
                </motion.a>
              </motion.div>
            );
          })}
        </motion.div>
        
        {/* Call to Action */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="mt-16 text-center"
        >
          <div className="glass p-8 rounded-xl max-w-2xl mx-auto border border-neon-primary/20">
            <h3 className="text-xl font-bold text-white mb-4" dir={isArabic ? 'rtl' : 'ltr'}>
              {isArabic ? "هل تحتاج إلى خدمة متخصصة؟" : "Need a specialized service?"}
            </h3>
            <p className="text-gray-300 mb-6" dir={isArabic ? 'rtl' : 'ltr'}>
              {isArabic ? 
                "نقدم حلولًا مخصصة لاحتياجاتك الفريدة. اتصل بنا اليوم لمناقشة مشروعك." : 
                "We provide tailored solutions for your unique needs. Contact us today to discuss your project."}
            </p>
            <motion.a 
              href="tel:+212631808007"
              className="inline-flex items-center px-6 py-3 bg-neon-primary hover:bg-neon-primary/80 text-gray-900 font-medium rounded-md shadow-neon transition-all"
              whileHover={{ scale: 1.05, boxShadow: '0 0 20px rgba(0, 242, 255, 0.6)' }}
              whileTap={{ scale: 0.95 }}
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={isArabic ? 'ml-2' : 'mr-2'}>
                <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
              </svg>
              {isArabic ? "اتصل للاستشارة المجانية" : "Call for Free Consultation"}
            </motion.a>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
