import { useEffect } from 'react';
import Navbar from './components/Navbar';
import HeroSection from './components/HeroSection';
import ServicesSection from './components/ServicesSection';
import BenefitsSection from './components/BenefitsSection';
import TransformationGallery from './components/TransformationGallery';
import PortfolioSection from './components/PortfolioSection';
import TestimonialsSection from './components/TestimonialsSection';
import PricingSection from './components/PricingSection';
import FAQSection from './components/FAQSection';
import ContactSection from './components/ContactSection';
import Footer from './components/Footer';
import { LanguageProvider } from './context/LanguageContext';
import ParticleBackground from './components/ParticleBackground';
import FloatingElements from './components/FloatingElements';
import ScrollProgressIndicator from './components/ScrollProgressIndicator';
import InteractiveServiceExplorer from './components/InteractiveServiceExplorer';
import ProjectViewer3D from './components/3DProjectViewer';
import ClientJourneySection from './components/ClientJourneySection';
import './index.css';

export default function App() {
  useEffect(() => {
    // Load Google Fonts
    const link = document.createElement('link');
    link.href = 'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Amiri:wght@400;700&display=swap';
    link.rel = 'stylesheet';
    document.head.appendChild(link);
    
    return () => {
      // Clean up
      document.head.removeChild(link);
    };
  }, []);

  return (
    <LanguageProvider>
      <div className="min-h-screen bg-dark-primary text-gray-200 relative">
        <ParticleBackground />
        <FloatingElements />
        <ScrollProgressIndicator />
        <Navbar />
        <main>
          <HeroSection />
          <div className="section-divider"></div>
          
          <ServicesSection />
          <div className="container mx-auto px-4 py-12">
            <InteractiveServiceExplorer />
          </div>
          <div className="section-divider"></div>
          
          <TransformationGallery />
          <div className="section-divider"></div>
          
          <BenefitsSection />
          <div className="section-divider"></div>
          
          <PortfolioSection />
          <div className="container mx-auto px-4 py-12">
            <ProjectViewer3D />
          </div>
          <div className="section-divider"></div>
          
          <TestimonialsSection />
          <div className="section-divider"></div>
          
          <ClientJourneySection />
          <div className="section-divider"></div>
          
          <PricingSection />
          <div className="section-divider"></div>
          
          <FAQSection />
          <div className="section-divider"></div>
          
          <ContactSection />
        </main>
        <Footer />
      </div>
    </LanguageProvider>
  );
}
