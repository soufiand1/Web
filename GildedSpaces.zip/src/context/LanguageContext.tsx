import React, { createContext, useState, useContext, ReactNode } from 'react';

// Define the available languages
export type Language = 'en' | 'ar';

// Create language context types
type LanguageContextType = {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
};

// Create the context with default values
const LanguageContext = createContext<LanguageContextType>({
  language: 'en',
  setLanguage: () => {},
  t: () => '',
});

// Create translation dictionary
const translations: Record<Language, Record<string, string>> = {
  en: {
    // Navbar
    'nav.services': 'Services',
    'nav.transformations': 'Transformations',
    'nav.benefits': 'Benefits',
    'nav.ourWork': 'Our Work',
    'nav.pricing': 'Pricing',
    'nav.contactUs': 'Contact Us',
    
    // Hero Section
    'hero.title': 'Elevate Your Shop With Expert Finishes',
    'hero.subtitle': 'We specialize in shop walls, bardage, wallpaper, and premium flooring for commercial spaces in Morocco. Transform your store today.',
    'hero.services': 'Our Services',
    'hero.callNow': 'Call Now',
    'hero.scrollDown': 'Scroll Down',
    
    // Services Section
    'services.title': 'Our Services',
    'services.subtitle': 'We transform your commercial space with professional finishes that reflect your brand.',
    'services.design.title': 'Shop Interior Design',
    'services.design.description': 'Transform your store with designs that blend style and function.',
    'services.design.feature1': 'Custom wall design',
    'services.design.feature2': 'Bardage installations',
    'services.design.feature3': 'Stylish wallpaper',
    'services.design.feature4': 'Placo plâtre solutions',
    'services.lighting.title': 'Lighting & Flooring',
    'services.lighting.description': 'Enhance your products with strategic lighting and premium flooring.',
    'services.lighting.feature1': 'Strategic display lighting',
    'services.lighting.feature2': 'Premium parquet installation',
    'services.lighting.feature3': 'Energy-efficient options',
    'services.lighting.feature4': 'Custom floor patterns',
    'services.maintenance.title': 'Maintenance Services',
    'services.maintenance.description': 'Keep your shop looking perfect with our maintenance packages.',
    'services.maintenance.feature1': 'Wall cleaning & repair',
    'services.maintenance.feature2': 'Bardage maintenance',
    'services.maintenance.feature3': 'Wallpaper touch-ups',
    'services.maintenance.feature4': 'Floor polishing',
    
    // Benefits Section
    'benefits.title': 'Benefits for Store Owners',
    'benefits.subtitle': 'How our services help your business succeed',
    'benefits.premium.title': 'Premium Shop Finishes',
    'benefits.premium.description': 'High-quality walls, bardage, and wallpaper that create an attractive shopping environment.',
    'benefits.engagement.title': 'Increased Customer Engagement',
    'benefits.engagement.description': 'Custom designs that showcase your products effectively and boost sales.',
    'benefits.durable.title': 'Durable Commercial Solutions',
    'benefits.durable.description': 'Materials selected for high-traffic commercial spaces, ensuring long-term performance.',
    'benefits.advantage.title': 'Stand Out From Competitors',
    'benefits.advantage.description': 'Custom bardage, premium flooring, and professional finishes that make your shop unique.',
    'benefits.callBtn': 'Call +212 631 808 007',
    
    // Portfolio Section
    'portfolio.title': 'Our Shop Renovations',
    'portfolio.subtitle': 'See our completed commercial store projects',
    'portfolio.all': 'All',
    'portfolio.stallWalls': 'Shop Walls',
    'portfolio.bardage': 'Bardage',
    'portfolio.papierPeint': 'Wallpaper',
    'portfolio.placoPlayre': 'Placo Plâtre',
    'portfolio.parquet': 'Flooring',
    'portfolio.description': 'Our team creates stunning retail environments with custom walls, quality bardage, elegant wallpaper, and premium flooring - all designed to enhance customer experience and boost sales.',
    'portfolio.cta': 'Transform Your Store',
    
    // Contact Section
    'contact.title': 'Contact Us',
    'contact.subtitle': 'Ready to transform your shop? Get in touch today.',
    'contact.callUs': 'Call Us Directly',
    'contact.whatsapp': 'WhatsApp',
    'contact.chatWithUs': 'Chat With Us',
    'contact.instagram': 'Instagram',
    
    // Footer
    'footer.description': 'We transform commercial stores with quality renovation and maintenance services, creating attractive shopping environments that combine style and function.',
    'footer.quickLinks': 'Quick Links',
    'footer.services': 'Services',
    'footer.transformations': 'Transformations',
    'footer.benefits': 'Benefits',
    'footer.ourWork': 'Our Work',
    'footer.pricing': 'Pricing',
    'footer.faq': 'FAQ',
    'footer.contact': 'Contact',
    'footer.contactUs': 'Contact Us',
    'footer.rights': 'All rights reserved.',
  },
  ar: {
    // Navbar
    'nav.services': 'خدماتنا',
    'nav.transformations': 'التحولات',
    'nav.benefits': 'المميزات',
    'nav.ourWork': 'أعمالنا',
    'nav.pricing': 'الأسعار',
    'nav.contactUs': 'اتصل بنا',
    
    // Hero Section
    'hero.title': 'ارتقِ بمتجرك مع تشطيبات احترافية',
    'hero.subtitle': 'نتخصص في جدران المحلات، كسوة الخشب، ورق الحائط، والأرضيات الفاخرة للمساحات التجارية في المغرب. حوّل متجرك اليوم.',
    'hero.services': 'خدماتنا',
    'hero.callNow': 'اتصل الآن',
    'hero.scrollDown': 'اسحب للأسفل',
    
    // Services Section
    'services.title': 'خدماتنا',
    'services.subtitle': 'نقوم بتحويل مساحتك التجارية بتشطيبات احترافية تعكس هوية علامتك التجارية.',
    'services.design.title': 'تصميم داخلي للمتاجر',
    'services.design.description': 'نحول متجرك بتصاميم تجمع بين الأناقة والوظائف العملية.',
    'services.design.feature1': 'تصميم جدران مخصص',
    'services.design.feature2': 'تركيب كسوة الخشب',
    'services.design.feature3': 'ورق حائط أنيق',
    'services.design.feature4': 'حلول الجبس',
    'services.lighting.title': 'الإضاءة والأرضيات',
    'services.lighting.description': 'تحسين عرض منتجاتك بإضاءة استراتيجية وأرضيات فاخرة.',
    'services.lighting.feature1': 'إضاءة عرض استراتيجية',
    'services.lighting.feature2': 'تركيب باركيه فاخر',
    'services.lighting.feature3': 'خيارات موفرة للطاقة',
    'services.lighting.feature4': 'تصاميم أرضيات مخصصة',
    'services.maintenance.title': 'خدمات الصيانة',
    'services.maintenance.description': 'حافظ على مظهر متجرك المثالي مع باقات الصيانة لدينا.',
    'services.maintenance.feature1': 'تنظيف وإصلاح الجدران',
    'services.maintenance.feature2': 'صيانة كسوة الخشب',
    'services.maintenance.feature3': 'تجديد ورق الحائط',
    'services.maintenance.feature4': 'تلميع الأرضيات',
    
    // Benefits Section
    'benefits.title': 'مميزات لأصحاب المتاجر',
    'benefits.subtitle': 'كيف تساعد خدماتنا عملك على النجاح',
    'benefits.premium.title': 'تشطيبات متجر فاخرة',
    'benefits.premium.description': 'جدران عالية الجودة، كسوة خشب، وورق حائط تخلق بيئة تسوق جذابة.',
    'benefits.engagement.title': 'زيادة تفاعل العملاء',
    'benefits.engagement.description': 'تصاميم مخصصة تعرض منتجاتك بفعالية وتعزز المبيعات.',
    'benefits.durable.title': 'حلول تجارية متينة',
    'benefits.durable.description': 'مواد مختارة للمساحات التجارية ذات الحركة العالية، مما يضمن الأداء على المدى الطويل.',
    'benefits.advantage.title': 'تميز عن المنافسين',
    'benefits.advantage.description': 'كسوة خشب مخصصة، أرضيات فاخرة، وتشطيبات احترافية تجعل متجرك فريداً.',
    'benefits.callBtn': 'اتصل بـ +212 631 808 007',
    
    // Portfolio Section
    'portfolio.title': 'تجديدات المتاجر',
    'portfolio.subtitle': 'شاهد مشاريعنا المنجزة للمتاجر التجارية',
    'portfolio.all': 'الكل',
    'portfolio.stallWalls': 'جدران المتاجر',
    'portfolio.bardage': 'كسوة خشب',
    'portfolio.papierPeint': 'ورق حائط',
    'portfolio.placoPlayre': 'جبس',
    'portfolio.parquet': 'أرضيات',
    'portfolio.description': 'يقوم فريقنا بإنشاء بيئات بيع رائعة مع جدران مخصصة، كسوة خشب عالية الجودة، ورق حائط أنيق، وأرضيات فاخرة - كل ذلك مصمم لتحسين تجربة العملاء وزيادة المبيعات.',
    'portfolio.cta': 'حوّل متجرك',
    
    // Contact Section
    'contact.title': 'اتصل بنا',
    'contact.subtitle': 'جاهز لتحويل متجرك؟ تواصل معنا اليوم.',
    'contact.callUs': 'اتصل بنا مباشرة',
    'contact.whatsapp': 'واتساب',
    'contact.chatWithUs': 'تحدث معنا',
    'contact.instagram': 'انستغرام',
    
    // Footer
    'footer.description': 'نقوم بتحويل المتاجر التجارية بخدمات تجديد وصيانة عالية الجودة، مما يخلق بيئات تسوق جذابة تجمع بين الأناقة والوظائف العملية.',
    'footer.quickLinks': 'روابط سريعة',
    'footer.services': 'الخدمات',
    'footer.transformations': 'التحولات',
    'footer.benefits': 'المميزات',
    'footer.ourWork': 'أعمالنا',
    'footer.pricing': 'الأسعار',
    'footer.faq': 'الأسئلة الشائعة',
    'footer.contact': 'اتصل',
    'footer.contactUs': 'اتصل بنا',
    'footer.rights': 'جميع الحقوق محفوظة.',
  }
};

// Provider component
export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('en');

  // Translation function
  const t = (key: string): string => {
    return translations[language][key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

// Custom hook for using the language context
export const useLanguage = () => useContext(LanguageContext);
